## 프론트엔드 토대 쌓기

- 프로젝트 생성

```bash
npx create-next-app@latest --ts
# or
yarn create next-app --typescript
```

- 웹서버 실행 후 결과 확인

```bash
npm run dev
```

<img src="./screenshot.png">