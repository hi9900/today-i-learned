
## axios 비동기 함수

4개의 처리 방식, 각 방식마다 각 2개의 코드(promise, await) 총 8개의 소스코드 구현

### Chaining 처리, Hard Code

  - promise_hard_code.js

  - await_hard_code.js

### Chining 처리, Soft Code

  - promise_soft_code.js

  - await_soft_code.js

### All 처리, 비순차 결과

  - promise_all_non_sequence.js

  - await_all_non_sequence.js

### All 처리, 순차 결과

  - promise_all_sequence.js

  - await_all_sequence.js

---

## 추가 비동기 함수

> ### fs

  - 파일 처리와 관련된 작업을 하는 모듈로, 보통 FileSystem을 줄여서 fs모듈이라 부른다.

    노드에서 가장 중요한 모듈 중 하나이다.

> ### fs method type

  - `fs.readFile(filename, [options], callback)`: filename의 파일을 [options]의 방식으로 읽은 후 callback으로 전달된 함수를 호출 (비동기적)

  - `fs.readFileSync(filename, [options])`: filename의 파일을 [options]의 방식으로 읽은 후 문자열을 반환 (동기적)

  - `fs.writeFile(filename, data, [options], callback)`: filename의 파일에 [options]의 방식으로 data 내용을 쓴 후 callback 함수를 호출 (비동기적)

  - `fs.writeFileSync(filename, data, [options])`: filename의 파일에 [options]의 방식으로 data 내용을 씀 (동기적)

