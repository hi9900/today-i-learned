## JIRA Project url

https://ssafy.atlassian.net/jira/software/c/projects/S09P10E126/boards/2026

## Filter url

https://ssafy.atlassian.net/issues?filter=20887

## Dashboard url

https://ssafy.atlassian.net/jira/dashboards/10170